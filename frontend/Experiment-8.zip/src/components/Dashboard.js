import React, { useEffect, useState } from "react";
import axios from "axios";

function Dashboard() {
  const [data, setData] = useState("");
  const token = sessionStorage.getItem("token");

  useEffect(() => {
    if (!token) {
      window.location.href = "/";
    }
  }, [token]);

  const getData = async () => {
    try {
      const res = await axios.get("http://localhost:5000/protected", {
        headers: {
          Authorization: "Bearer " + token
        }
      });

      setData(res.data.message || JSON.stringify(res.data));
    } catch (error) {
      alert("Unauthorized ❌");
      console.log(error);
    }
  };

  const logout = () => {
    sessionStorage.removeItem("token");
    window.location.href = "/";
  };

  return (
    <div className="container mt-5">
      <h2 className="mb-4">Dashboard</h2>

      <button className="btn btn-success me-2" onClick={getData}>
        Fetch Data
      </button>

      <button className="btn btn-danger" onClick={logout}>
        Logout
      </button>

      <div className="mt-4">
        <h5>Response:</h5>
        <p>{data}</p>
      </div>
    </div>
  );
}

export default Dashboard;