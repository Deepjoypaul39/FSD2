function Navbar() {
  return <h2>My Portfolio</h2>;
}
export default Navbar;
